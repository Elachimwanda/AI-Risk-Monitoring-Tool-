import streamlit as st
import pandas as pd
import sqlite3

st.title("AI Risk Monitor Dashboard")

conn = sqlite3.connect("data/risk_logs.db")
df = pd.read_sql_query("SELECT * FROM risks", conn)
st.dataframe(df)