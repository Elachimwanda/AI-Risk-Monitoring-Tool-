from monitor.metrics import detect_model_drift

def test_model_drift():
    current = [0.1, 0.2, 0.3]
    previous = [0.1, 0.15, 0.2]
    assert not detect_model_drift(current, previous, threshold=0.2)