from fastapi import FastAPI, Request
from monitor.risk_rules import detect_prompt_injection

app = FastAPI()

@app.post("/scan_input")
async def scan_input(req: Request):
    body = await req.json()
    input_text = body.get("input")
    if detect_prompt_injection(input_text):
        return {"risk": "Prompt Injection Detected"}
    return {"risk": "None"}