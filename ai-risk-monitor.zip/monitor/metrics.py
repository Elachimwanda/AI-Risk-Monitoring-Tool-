from scipy.stats import wasserstein_distance

def detect_model_drift(current_preds, previous_preds, threshold=0.1):
    drift_score = wasserstein_distance(current_preds, previous_preds)
    return drift_score > threshold