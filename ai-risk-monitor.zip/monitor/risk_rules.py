def detect_prompt_injection(input_text):
    suspicious_patterns = ["ignore previous instructions", "execute", "bypass", "admin password"]
    return any(pattern in input_text.lower() for pattern in suspicious_patterns)

def log_risk(risk_type, details):
    import sqlite3, datetime
    conn = sqlite3.connect('data/risk_logs.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS risks (timestamp TEXT, type TEXT, details TEXT)''')
    c.execute("INSERT INTO risks VALUES (?, ?, ?)", (datetime.datetime.now(), risk_type, details))
    conn.commit()
    conn.close()